package com.wedding.model;

public class FreeOrder {
private int o_id;
private int ho_id;
private int h_id;
private int c_id;
private int mc_id;
private int wg_id;
private int userid;
private int uc_id;
public int getO_id() {
	return o_id;
}
public void setO_id(int o_id) {
	this.o_id = o_id;
}
public int getHo_id() {
	return ho_id;
}
public void setHo_id(int ho_id) {
	this.ho_id = ho_id;
}
public int getH_id() {
	return h_id;
}
public void setH_id(int h_id) {
	this.h_id = h_id;
}
public int getC_id() {
	return c_id;
}
public void setC_id(int c_id) {
	this.c_id = c_id;
}
public int getMc_id() {
	return mc_id;
}
public void setMc_id(int mc_id) {
	this.mc_id = mc_id;
}
public int getWg_id() {
	return wg_id;
}
public void setWg_id(int wg_id) {
	this.wg_id = wg_id;
}
public int getUserid() {
	return userid;
}
public void setUserid(int userid) {
	this.userid = userid;
}
public int getUc_id() {
	return uc_id;
}
public void setUc_id(int uc_id) {
	this.uc_id = uc_id;
}
}
