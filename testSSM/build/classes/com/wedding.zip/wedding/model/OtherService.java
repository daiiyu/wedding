package com.wedding.model;

public class OtherService {
      private int os_id;
      private int o_id;
      private String os_introduce;
	public int getOs_id() {
		return os_id;
	}
	public void setOs_id(int os_id) {
		this.os_id = os_id;
	}
	public int getO_id() {
		return o_id;
	}
	public void setO_id(int o_id) {
		this.o_id = o_id;
	}
	public String getOs_introduce() {
		return os_introduce;
	}
	public void setOs_introduce(String os_introduce) {
		this.os_introduce = os_introduce;
	}
}
