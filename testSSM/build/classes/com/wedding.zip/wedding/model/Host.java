package com.wedding.model;

public class Host {
  private int h_id;
  private int o_id;
  private String h_name;
  private String h_sex;
  private int h_age;
  private String h_tel;
  private String h_introduce;
  public int getH_id() {
	return h_id;
}
public void setH_id(int h_id) {
	this.h_id = h_id;
}
public int getO_id() {
	return o_id;
}
public void setO_id(int o_id) {
	this.o_id = o_id;
}
public String getH_name() {
	return h_name;
}
public void setH_name(String h_name) {
	this.h_name = h_name;
}
public String getH_sex() {
	return h_sex;
}
public void setH_sex(String h_sex) {
	this.h_sex = h_sex;
}
public int getH_age() {
	return h_age;
}
public void setH_age(int h_age) {
	this.h_age = h_age;
}
public String getH_tel() {
	return h_tel;
}
public void setH_tel(String h_tel) {
	this.h_tel = h_tel;
}
public String getH_introduce() {
	return h_introduce;
}
public void setH_introduce(String h_introduce) {
	this.h_introduce = h_introduce;
}

}
