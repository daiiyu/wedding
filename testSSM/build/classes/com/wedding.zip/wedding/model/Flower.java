package com.wedding.model;

public class Flower {
  private int f_id;
  private String f_name;
  private int f_price;
public int getF_id() {
	return f_id;
}
public void setF_id(int f_id) {
	this.f_id = f_id;
}
public String getF_name() {
	return f_name;
}
public void setF_name(String f_name) {
	this.f_name = f_name;
}
public int getF_price() {
	return f_price;
}
public void setF_price(int f_price) {
	this.f_price = f_price;
}
}
