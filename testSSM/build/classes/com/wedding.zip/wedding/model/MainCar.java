package com.wedding.model;

public class MainCar {
	private int mc_id;
	private int o_id;
	private String mc_name;
	private String mc_style;
	private String mc_color;
	private String mc_price;
	public int getMc_id() {
		return mc_id;
	}
	public void setMc_id(int mc_id) {
		this.mc_id = mc_id;
	}
	public int getO_id() {
		return o_id;
	}
	public void setO_id(int o_id) {
		this.o_id = o_id;
	}
	public String getMc_name() {
		return mc_name;
	}
	public void setMc_name(String mc_name) {
		this.mc_name = mc_name;
	}
	public String getMc_style() {
		return mc_style;
	}
	public void setMc_style(String mc_style) {
		this.mc_style = mc_style;
	}
	public String getMc_color() {
		return mc_color;
	}
	public void setMc_color(String mc_color) {
		this.mc_color = mc_color;
	}
	public String getMc_price() {
		return mc_price;
	}
	public void setMc_price(String mc_price) {
		this.mc_price = mc_price;
	}
}
