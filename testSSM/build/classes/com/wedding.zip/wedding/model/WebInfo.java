package com.wedding.model;

public class WebInfo {
 private int wi_id;
 private int m_id;
 private String wi_name;
 private String wi_introduce;
public int getWi_id() {
	return wi_id;
}
public void setWi_id(int wi_id) {
	this.wi_id = wi_id;
}
public int getM_id() {
	return m_id;
}
public void setM_id(int m_id) {
	this.m_id = m_id;
}
public String getWi_name() {
	return wi_name;
}
public void setWi_name(String wi_name) {
	this.wi_name = wi_name;
}
public String getWi_introduce() {
	return wi_introduce;
}
public void setWi_introduce(String wi_introduce) {
	this.wi_introduce = wi_introduce;
}
}
