package com.wedding.model;

public class UsherCar {
  private int uc_id;
  private int o_id;
  private String uc_name;
  private String uc_style;
  private int uc_price;
  private String uc_color;
public int getUc_id() {
	return uc_id;
}
public void setUc_id(int uc_id) {
	this.uc_id = uc_id;
}
public int getO_id() {
	return o_id;
}
public void setO_id(int o_id) {
	this.o_id = o_id;
}
public String getUc_name() {
	return uc_name;
}
public void setUc_name(String uc_name) {
	this.uc_name = uc_name;
}
public String getUc_style() {
	return uc_style;
}
public void setUc_style(String uc_style) {
	this.uc_style = uc_style;
}
public int getUc_price() {
	return uc_price;
}
public void setUc_price(int uc_price) {
	this.uc_price = uc_price;
}
public String getUc_color() {
	return uc_color;
}
public void setUc_color(String uc_color) {
	this.uc_color = uc_color;
}
}
