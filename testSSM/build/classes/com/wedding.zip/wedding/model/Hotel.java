package com.wedding.model;

public class Hotel {
	private int ho_id;
	private int o_id;
	private String ho_name;
	private int ho_price;
	private String h0_introduce;
	public int getHo_id() {
		return ho_id;
	}
	public void setHo_id(int ho_id) {
		this.ho_id = ho_id;
	}
	public int getO_id() {
		return o_id;
	}
	public void setO_id(int o_id) {
		this.o_id = o_id;
	}
	public String getHo_name() {
		return ho_name;
	}
	public void setHo_name(String ho_name) {
		this.ho_name = ho_name;
	}
	public int getHo_price() {
		return ho_price;
	}
	public void setHo_price(int ho_price) {
		this.ho_price = ho_price;
	}
	public String getH0_introduce() {
		return h0_introduce;
	}
	public void setH0_introduce(String h0_introduce) {
		this.h0_introduce = h0_introduce;
	}
}
